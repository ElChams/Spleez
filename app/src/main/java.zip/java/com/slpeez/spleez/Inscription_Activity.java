package com.slpeez.spleez;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by alexduffaut on 16/05/16.
 */
public class Inscription_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inscription_activity);



    }

}
