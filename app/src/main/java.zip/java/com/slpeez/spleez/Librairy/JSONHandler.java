package com.slpeez.spleez.Librairy;

import android.content.Context;

import com.slpeez.spleez.Object.Event;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;


/**
 * A class used to handle JSON responses from the server.
 * JSON is standard format used to represent datas.
 * @author thibaut chamoux
 * @version 1.0
 */
public class JSONHandler {

    private static Context _context;

    URLHandler _urlHandler;

    /* Just modify the URL to fit the correct address of the server */
    private static String _loginURL = "http://192.168.1.37:8000/login.py";
    private static String _getActivities = "http://192.168.1.37:8000/activities";
    private static String _createNewActivity = "http://192.168.1.37:8000/create_new_activity.py";

    public JSONHandler(Context c) {

        _context = c;
        _urlHandler = new URLHandler(_context);
    }


    public JSONObject isUserValid(String login, String password) throws IOException {

        JSONObject user = new JSONObject();

        try {
            user.put("login", login);
            user.put("password", password);
            String response = _urlHandler.makeRequest(_loginURL);
            return new JSONObject(response);

        } catch(JSONException je) {

        }
        return null;
    }

    public ArrayList<Event> getListEvent() throws IOException {

        ArrayList<Event> result = new ArrayList<>();
        try {
            String response = _urlHandler.makeRequest(_getActivities);
            JSONArray ja = new JSONArray(response);

            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = ja.getJSONObject(i);
                String name = jo.getString("actname");
                String desc = jo.getString("actdesc");
                Event e = new Event();
                e.setDesc(desc);
                e.setName(name);
                result.add(e);
            }
        } catch(JSONException je) {

        }
        return result;
    }



}
